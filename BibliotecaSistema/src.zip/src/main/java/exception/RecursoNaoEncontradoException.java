package exception;

public class RecursoNaoEncontradoException extends Exception {
    public RecursoNaoEncontradoException(String mensagem) {
        super(mensagem);
    }
}
